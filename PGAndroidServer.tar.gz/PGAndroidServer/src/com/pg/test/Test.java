package com.pg.test;

import com.pg.daoimpl.UserDaoImpl;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserDaoImpl userDaoImpl=new UserDaoImpl();
		userDaoImpl.check("13581905786");
	}

}
